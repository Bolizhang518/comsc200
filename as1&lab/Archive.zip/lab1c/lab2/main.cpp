#include <iostream>
#include "Rectangle.h"  // Needed for Rectangle class
using namespace std;

int main()
{
    Rectangle box;     // Define an instance of the Rectangle class
    double rectWidth;  // Local variable for width
    double rectLength; // Local variable for length
    
    // Get the rectangle's width and length from the user.
    cout << "This program will calculate the area of a\n";
    cout << "rectangle. What is the width? ";
    cin >> rectWidth;              //这里的值还在本地 需要转到class
    cout << "What is the length? ";
    cin >> rectLength;            //这里的值还在本地 需要转到class
    
    // Store the width and length of the rectangle
    // in the box object.
    box.setWidth(rectWidth);     //这里把值 送到 class， 但不能反回  name.class(varibale) 只有进去没有回来
    box.setLength(rectLength);
    
    // Display the rectangle's data.
    cout << "Here is the rectangle's data:\n";
    cout << "Width: " << box.getWidth() << endl;     //这里可以返回 name.class() 没有进去，只有返回。
    cout << "Length: " << box.getLength() << endl;
    cout << "Area: " << box.getArea() << endl;
    return 0;
}