//
//  Rectangle.h
//  lab2
//
//  Created by Jeff on 8/17/16.
//  Copyright © 2016 Jeff. All rights reserved.
//

#ifndef Rectangle_h
#define Rectangle_h
class Rectangle{
private:
    double width;   //从CPP 那边访问不到这里  只是方便header内部使用的varibale 
    double length;
public:
    //constructors
    Rectangle(){width =1; length=1;}; //default construct  , nothing knows here
    Rectangle(double w , double l) {width=w; length=l;};
    
    //getters
    void setWidth(double w) {width=w;};
    void setLength(double l){length =l ;};
    
    
    //setters
    double getWidth()const {return width;};
    double getLength()const {return width;};
    
    //feature functions(methods)
    double getArea() {return width*length;};
    
    
};

#endif /* Rectangle_h */
