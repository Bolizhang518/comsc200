//
//  Date.h
//  lab1d
//
//  Created by Jeff on 8/17/16.
//  Copyright © 2016 Jeff. All rights reserved.
//

#ifndef Date_h
#define Date_h
const int NUM_MONTHS=12;
class Date{
    
  private:
    int day;
    int month;
    int year;
    std:: string names[NUM_MONTHS];
    //private helper
    void setNames(){
        names[0] = "Jan";
        names[1] = "Feb";
        names[2] = "Mar";
        names[3] = "Apr";
        names[4] = "May";
        names[5] = "Jun";
        names[6] = "Jul";
        names[7] = "Aug";
        names[8] = "Sept";
        names[9] = "Oct";
        names[10] = "Nov";
        names[11] = "Dec";
        
        
        
    };
public:
    //Date(){day=1;month=1;year=2016;};
    Date(int d,int m, int y){
        
        setDay(d);
        setMonth(m);
        setYear(y);
        setNames();
        }
    //setters
    void setDay(int d){day=d;};
    void setMonth(int m){month=m;};
    void setYear(int y){year=y;};
    //getters
    int getDay()const{return day;};
    int getMonth()const{return month;};
    int getYear()const{return year;};
    
    //feature methods
    //1/1/2016
    void showData1(){
        std::cout<<month <<"/" <<day << "/" <<year << std::endl;
    }
    //january 1,2016
    void showData2(){
        std::cout<<names[month-1] <<" "<<day<<" , "<< year <<std::endl;
    }
    //1 january,2016
    void showData3(){
        std::cout<<day<<" "<<names[month-1]<<" , " <<year <<std::endl;
    }
};

#endif /* Date_h */
