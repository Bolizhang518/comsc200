//
//  main.cpp
//  lab1xcode
//
//  Created by Jeff on 8/17/16.
//  Copyright © 2016 Jeff. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void insertVec(vector<double>&); //decleare the parmeter vector here
void display(vector<double>&);
void Maxrain(vector<double>&);
void Small(vector<double>&);

int const Num_vec = 12;
int main()
{
  //  int sum_of_elems = 0;
    vector<double>myvector;
  /*
    vector<int>myvector;
  
    for(int i=0;i<3;i++)
    {
        cout<<"enter vector: " << endl;
        int nums;
        cin>>nums;
        
        myvector.push_back(nums);
    }
        for(vector<int>::iterator it = myvector.begin(); it != myvector.end(); ++it)
        
            sum_of_elems += *it;
    
    cout << " this is standerd vector version total sum: " << sum_of_elems << endl;
   
   */
    //=====================================================================================
    // parmeter verstion vector below
    
    insertVec(myvector);
    display(myvector);
    Maxrain(myvector);
    Small(myvector);
    
}
//insert vector using paremeter vector
void insertVec(vector<double>& newvector){
    double value;
    int Num=0;
    for(int i=0;i<Num_vec;i++){
        cout<<"enter the rainfall for month # " <<Num+1 << " : ";
        cin>>value;
        newvector.push_back(value);
        Num++;
        
    }
    
    
}
// display the sum of the vector using parameter vector
void display(vector<double>& myvector){
   // cout<<"this is parmeter vector, sum of them : ";
    // for(vector<int>::iterator it = myVector.begin(); it != myVector.end();++it)
    int total = 0 ;
    for(auto item:myvector){
        total+=item;
        //cout<< "total1: "<< total << ' '<<endl;
    
    }
    cout<<"total rainfall: "<< total <<' '<<endl;
    cout <<"average rainfall: " << total/Num_vec << ' '<<endl;
    
}

void Maxrain(vector<double>&myvector){
    double max=0;
    int month=0;
    for(auto item:myvector)
    {
        if(myvector[max]<myvector[month])
            max = month;
            month++;
    }
    
    cout<<"max rainfall is :"<<myvector[max] << ' ' << "in "<< max+1 << " month"<< endl;
}


void Small(vector<double>&myvector){
    int small=0;
    int month=0;
    for(auto item:myvector){
        if(myvector[small]>myvector[month])
            small = month;
        month++;
        
    }
    cout<<"smallest is " <<myvector[small]<<' '<< "in "<<small+1<<endl;
    
    
}